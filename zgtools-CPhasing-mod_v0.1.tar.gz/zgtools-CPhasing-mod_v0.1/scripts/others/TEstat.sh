#!/bin/bash
bin_dir=`realpath $0|xargs -n1 dirname`
te_gff=`realpath genome.fa.mod.EDTA.TEanno.gff3`
genome_len=`cat genome.fa.mod.stats|cut -f2`
cat <(echo -e "Class\tFamily\tCount\tbpMasked\t%masked") \
<(cat ${bin_dir}/classify.xls|sed '/^$/d'|cut -f2|uniq|while read n
do
	if [ `echo "$n"|grep "All"|wc -l` == "0" ];then
		grep_used=`grep -w "$n" ${bin_dir}/classify.xls |cut -f1|sed 's/^/classification=/g'|sed 's/$/;/g'|tr '\n' '|'|sed 's/|$/\n/g'`
		count=`grep -E "$grep_used" $te_gff|wc -l`
		len=`grep -E "$grep_used" $te_gff|cut -f1,4-5|sort -k1 -V|bedtools merge -nonamecheck|awk '{print $3-$2+1}'|awk '{sum+=$1}END{print sum}'|sed 's/^$/0/g'`
		pct=`echo -e "$len\t$genome_len"|awk '{printf "%.2f\n", $1/$2*100}'`
		echo -e "$n\t$count\t$len\t$pct"
	else
		echo -e "-/-\t-\t-\t-\t-"
		if [ "$n" != "DNA/All" ];then
			grep_used=`echo "$n"|sed 's/\/All//g'|sed 's/^/classification=/g'`
		else
			grep_used=`echo -e "classification=DNA/|classification=MITE/"`
		fi
		count=`grep -E "$grep_used" $te_gff|wc -l`
		len=`grep -E "$grep_used" $te_gff|cut -f1,4-5|sort -k1 -V|bedtools merge -nonamecheck|awk '{print $3-$2+1}'|awk '{sum+=$1}END{print sum}'|sed 's/^$/0/g'`
		pct=`echo -e "$len\t$genome_len"|awk '{printf "%.2f\n", $1/$2*100}'`
		echo -e "$n\t$count\t$len\t$pct"
	fi
done) >genome.fa.mod.EDTA.TEanno.sum.tmp1 && \
cat genome.fa.mod.EDTA.TEanno.sum.tmp1|sed '/TIR\/P\t/d'|sed 's#/#\t#g'|awk 'BEGIN{FS=OFS="\t"} NR<=1{print; next} {for(i=3;i<=NF;i++) if($i~/^[0-9]+$/) $i=sprintf("%'\''d", $i)} 1'|sed 's/^Helitron/NonTIR/g'|sed 's/^\tAll/Total-TE\tAll/g'|sed '/DIRS/d'|grep -vE "Merlin|Transib|PiggyBac|Crypton|Maverick|Jockey" |awk '{if(NR>1&&$1==p)$1="-"; else p=$1} 1'|column -t >genome.fa.mod.EDTA.TEanno.sum.tmp2 && \
for i in 1 2 3 4 5 6 7 8 20 25 23 24 21 22 26 27 10 11 12 13 14 15 16 17 18 19 28 29;do sed '/-$/d' genome.fa.mod.EDTA.TEanno.sum.tmp2|sed -n "${i}p";done|sed 's#^TIR#-#g'|sed 's#- * CACTA#TIR CACTA#g'|column -t|sed 's/All/---/g'|sed 's/-/ /g'|sed 's/Bel /Bel-/g;s/PIF /PIF-/g;s/Tc1 /Tc1-/g' >genome.fa.mod.EDTA.TEanno.sum.txt && \
rm -rf genome.fa.mod.EDTA.TEanno.sum.tmp* && \
cat genome.fa.mod.EDTA.TEanno.sum.txt|sed 's/Total TE * /Total-TE\t\t/g'|sed 's/Unknown * /Unknown\t\t/g'|sed 's/unknown * /unknown\t/g'|sed 's/DNA * /DNA\t\t/g'|sed 's/INE * /INE\t\t/g'|sed 's/LTR * /LTR\t\t/g'|sed 's/ * /\t/g'|sed 's/Total-TE/Total TE/g' >genome.fa.mod.EDTA.TEanno.sum.xls && \
cat genome.fa.mod.EDTA.TEanno.sum.txt
